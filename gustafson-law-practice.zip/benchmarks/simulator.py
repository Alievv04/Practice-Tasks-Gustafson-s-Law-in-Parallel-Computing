#!/usr/bin/env python3
"""Amdahl vs Gustafson simulator (Task 21).

Usage:
  python simulator.py                      # defaults
  python simulator.py --alphas 0.01 0.05 0.2 --pmax 65536 --csv out.csv --plot out.png
"""
import argparse
import csv

import numpy as np


def amdahl(P, s):
    return 1.0 / (s + (1.0 - s) / P)


def gustafson(P, a):
    return P - a * (P - 1.0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alphas", type=float, nargs="+", default=[0.001, 0.01, 0.05, 0.10, 0.20])
    ap.add_argument("--pmax", type=int, default=65536)
    ap.add_argument("--csv", default="speedup_data.csv")
    ap.add_argument("--plot", default="../plots/scaling_comparison.png")
    args = ap.parse_args()

    if not 1 <= args.pmax <= 65536:
        ap.error("pmax must be in [1, 65536]")
    for a in args.alphas:
        if not 0.001 <= a <= 0.20:
            ap.error(f"alpha {a} outside [0.001, 0.20]")

    Ps = np.unique(np.concatenate([2 ** np.arange(0, int(np.log2(args.pmax)) + 1), [args.pmax]]))

    rows = []
    for a in args.alphas:
        for P in Ps:
            sa, sg = amdahl(P, a), gustafson(P, a)
            rows.append(dict(alpha=a, P=int(P), amdahl_S=sa, amdahl_E=sa / P,
                             gustafson_S=sg, gustafson_E=sg / P))

    with open(args.csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {len(rows)} rows to {args.csv}")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib not installed; skipping plot")
        return

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
    ax1.loglog(Ps, Ps, "k--", label="Ideal (S = P)")
    for a in args.alphas:
        ax1.loglog(Ps, [gustafson(P, a) for P in Ps], "-", label=f"Gustafson α={a}")
        ax1.loglog(Ps, [amdahl(P, a) for P in Ps], ":", label=f"Amdahl s={a}")
    ax1.set_xlabel("Processors P"); ax1.set_ylabel("Speedup")
    ax1.set_title("Weak (Gustafson) vs strong (Amdahl) scaling")
    ax1.legend(fontsize=7, ncol=2); ax1.grid(True, which="both", alpha=0.3)

    for a in args.alphas:
        ax2.semilogx(Ps, [gustafson(P, a) / P for P in Ps], "-", label=f"Gustafson α={a}")
        ax2.semilogx(Ps, [amdahl(P, a) / P for P in Ps], ":", label=f"Amdahl s={a}")
    ax2.set_xlabel("Processors P"); ax2.set_ylabel("Efficiency")
    ax2.set_title("Parallel efficiency"); ax2.grid(True, which="both", alpha=0.3)
    fig.tight_layout()
    fig.savefig(args.plot, dpi=200)
    print(f"saved {args.plot}")


if __name__ == "__main__":
    main()
