# Gustafson's Law & Weak Scaling — Practice Repository

## Core formulas
- Scaled speedup: `S(P) = P − α(P−1)`; efficiency `E(P) = 1 − α(1 − 1/P)` → `1 − α` as P→∞
- Amdahl: `S(P) = 1/(s + (1−s)/P)`, bounded by `1/s`, efficiency → 0
- α is measured on the **parallel** run; the problem grows with P so the serial share is amortized.

## When to design for weak scaling
Use it when the science benefits from bigger problems (finer grids, more particles/samples) and
time-to-solution is fixed. Prefer strong-scaling analysis when the problem size is fixed (e.g. a
latency-bound production job). Verify the assumptions: α stays constant, per-node memory suffices,
communication does not grow with P (see Task 12).

## Status / index
| Task | Artifact | Status |
|---|---|---|
| 02 | theory/task02_derivation.md | done |
| 04 | theory/task04_asymptotic_limits.md | done |
| 06–10 | calculations/task06…task10 | done |
| 16 | calculations/task16_gemm_scaling.md | done |
| 21 | benchmarks/simulator.py | done |
| 01, 03, 05, 11–15, 17–20, 22–25 | — | TODO |

## Run
```
cd benchmarks && python simulator.py   # writes speedup_data.csv and ../plots/scaling_comparison.png
```
