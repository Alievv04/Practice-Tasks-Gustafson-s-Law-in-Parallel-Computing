# Task 02 — Derivation of Gustafson's Scaled Speedup

## Setup
Fix the **parallel wall-clock time** on P processors and normalize it:

    s + p = 1        (s = serial part, p = parallel part, both measured ON the P-core run)

The serial fraction as observed on the parallel machine is alpha = s (since s + p = 1).

## Step 1 — Work done on the parallel machine
Each of the P cores executes the parallel part for time p simultaneously.
Total work, in "single-core seconds":

    W_total = s + P·p                                   (1)

(The serial part runs once; the parallel part is done by all P cores at once.)

## Step 2 — Time for ONE core to do the same scaled work
Assuming perfect divisibility and no extra serial work:

    T(1) = s + P·p                                      (2)

## Step 3 — Scaled speedup
    S(P) = T(1) / T(P) = (s + P·p) / (s + p) = s + P·p  (3)   [since s + p = 1]

## Step 4 — Rewrite using alpha
Substitute p = 1 − alpha, s = alpha:

    S(P) = alpha + P(1 − alpha)
         = alpha + P − P·alpha
         = P − alpha(P − 1)                             (4)   ∎

## Interpretation
- S(P) is **linear in P with slope (1 − alpha)**, not bounded by 1/alpha.
- The loss from ideal is only alpha(P−1).
- Caveat: Eq. (2) assumes the serial portion does not grow with problem size and that the
  scaled problem could (hypothetically) run on one core. That is why S is called *scaled* speedup.
