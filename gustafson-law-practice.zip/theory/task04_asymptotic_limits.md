# Task 04 — Asymptotic Parallel Efficiency

## Gustafson
    E(P) = S(P)/P = (P − alpha(P−1))/P = 1 − alpha(1 − 1/P)

    lim_{P→∞} E(P) = 1 − alpha·(1 − 0) = 1 − alpha

Proof: 1/P → 0 and the expression is continuous in 1/P. ∎
E(P) decreases monotonically from E(1) = 1 toward the floor 1 − alpha
(e.g. alpha = 0.04 → 0.96).

## Amdahl (fixed size, serial fraction s)
    S_A(P) = 1/(s + (1−s)/P)
    E_A(P) = 1/(sP + (1−s))

    lim_{P→∞} E_A(P) = 0   (denominator ~ sP → ∞ for any s > 0)
    lim_{P→∞} S_A(P) = 1/s

## Contrast
| Model | lim S(P) | lim E(P) | Growth of S |
|---|---|---|---|
| Gustafson | ∞ (slope 1−alpha) | 1 − alpha | Θ(P) |
| Amdahl | 1/s (bounded) | 0 | O(1) |

Amdahl holds work fixed, so per-core work vanishes while the serial part stays.
Gustafson holds per-core work fixed, so the serial part is amortized over ever more parallel work.
