# Task 09 — Three-phase simulation
Phases (fractions of parallel runtime): A I/O+broadcast 2%, B boundary sync 6%, C compute 92%.
Treating A and B as non-scaling overhead: **alpha = 0.02 + 0.06 = 0.08**.
(Judgment call: B is communication, which often grows with P — see Task 12 — but classic
Gustafson counts it in the non-scaling fraction.)

| P | S(P) = P − 0.08(P−1) | E(P) |
|---:|---:|---:|
| 512 | 471.12 | 0.9202 |
| 2,048 | 1,884.24 | 0.9200 |

Working: 512 − 0.08·511 = 471.12; 2048 − 0.08·2047 = 1884.24.
Amdahl with s = 0.08 would give 12.23 and 12.43 at these P (cap 12.5).
