# Task 16 — GEMM under fixed time
Work = Θ(N^3); constant time T = c·N^3/P  ⇒  N^3 ∝ P  ⇒  **N(P) = N(1)·P^(1/3)**.
Total memory Θ(N^2) = Θ(P^(2/3)); per-node memory Θ(P^(-1/3)) shrinks, so communication, not
memory, is the binding constraint.

Targets for N(1) = 1000:
| P | N |
|---:|---:|
| 1 | 1,000 |
| 8 | 2,000 |
| 64 | 4,000 |
| 512 | 8,000 |
| 4,096 | 16,000 |
| 32,768 | 32,000 |

Contrast with fixed-memory-per-node scaling: N ∝ P^(1/2), work ∝ P^(3/2), time ∝ P^(1/2),
which violates the fixed-time premise.
