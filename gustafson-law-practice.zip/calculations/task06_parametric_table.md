# Task 06 — alpha = 0.04
S(P) = P − 0.04(P−1),  E(P) = S(P)/P  (Amdahl column uses s = 0.04, for contrast)

| P | S(P) | E(P) | Amdahl S |
|---:|---:|---:|---:|
| 16 | 15.40 | 0.9625 | 10.000 |
| 64 | 61.48 | 0.9606 | 18.182 |
| 256 | 245.80 | 0.9602 | 22.857 |
| 1,024 | 983.08 | 0.9600 | 24.427 |
| 4,096 | 3,932.20 | 0.9600 | 24.854 |
| 16,384 | 15,728.68 | 0.9600 | 24.963 |

Example: P = 64 → 64 − 0.04·63 = 61.48; E = 61.48/64 = 0.9606.

**Evaluation:** efficiency barely degrades as P grows exponentially; it falls from 96.25% to its
asymptote 96.00% = 1 − alpha. Amdahl at the same fraction saturates near 25 (= 1/0.04).
