# Task 07 — Maximum tolerable alpha
Require S(P) = P − alpha(P−1) ≥ 7500 with P = 8192.

    8192 − alpha·8191 ≥ 7500
    alpha·8191 ≤ 692
    alpha ≤ 692/8191 = 0.084483

**alpha_max ≈ 0.0845 (8.45%)**.
Check: 8192 − 0.084483·8191 = 7500.0 ✓. Required efficiency = 7500/8192 = 91.55%.
