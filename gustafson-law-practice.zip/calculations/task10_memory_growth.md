# Task 10 — Memory ceiling for a 3D grid
Assumptions (explicit): double precision (8 B/cell), 2 arrays (old/new), so 16 B/cell;
32 GB = 2^35 B per node; memory evenly distributed.

Per-node cells: n^3 ≤ 2^35 / 16 = 2^31  →  n = 2^(31/3) ≈ **1,290**.
Global grid under weak scaling: N = P^(1/3)·n.

| Nodes P | N (global edge) | Cells |
|---:|---:|---:|
| 64 | ≈ **5,160** | 1.37×10^11 |
| 512 | ≈ **10,321** | 1.10×10^12 |

Sensitivity: with 1 array (8 B/cell) n ≈ 1,625 → N ≈ 6,502 (64 nodes), 13,004 (512 nodes).
Since memory is linear in P but N ∝ P^(1/3), 8x the nodes only doubles the edge length.
Real codes need halos and buffers, so leave headroom.
