# Task 08 — Amdahl vs Gustafson, s = alpha = 0.08, P = 128

Amdahl: S_A = 1/(0.08 + 0.92/128) = 1/0.0871875 = **11.47**
Gustafson: S_G = 128 − 0.08·127 = **117.84**

Discrepancy:
- Gustafson is 927.4% higher than Amdahl ((117.84−11.47)/11.47)
- Amdahl is 90.3% lower than Gustafson ((117.84−11.47)/117.84)
- Ratio S_G/S_A = 10.27

**Why they diverge:** the same number means different things. In Amdahl, s is the serial share of the
*fixed single-core* run, so serial time stays 8% of T(1) while parallel time shrinks as 1/P.
In Gustafson, alpha is 8% of the *P-core* run on an enlarged problem; on one core the serial part
would be only 0.08/117.84 ≈ 0.07% of the time. As P grows, S_A → 12.5 while S_G grows without bound.
The models answer different questions (fixed work vs. fixed time).
